﻿Option Explicit On
Module MainModule

    Sub Main()
        TestSecantOne()
        TestSecantTwo()
        TestSecantThree()
    End Sub

    Public Sub TestSecantOne()
        Dim root As Double

        root = CubicSecant((-1), 1, 0.00000001, 100, {1, 0, 0, 0})

        Console.WriteLine("A root was found at x = {0}", root)

    End Sub

    Public Sub TestSecantTwo()
        Dim root As Double

        root = CubicSecant((-0.5), 1, 0.00000001, 100, {1, 1, 0, 0})

        Console.WriteLine("A root was found at x = {0}", root)

    End Sub

    Public Sub TestSecantThree()
        Dim root As Double

        root = CubicSecant((-1), 1, 0.00000001, 100, {(-2), 1, (-1), 0.5})

        Console.WriteLine("A root was found at x = {0}", root)

    End Sub
End Module
