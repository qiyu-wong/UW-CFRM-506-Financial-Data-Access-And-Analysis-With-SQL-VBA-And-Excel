﻿Option Explicit On
Imports System.Math
Module PolyRoot


    Private Function Poly(x0 As Double, x1 As Double, ByVal v() As Double) As Double

        Dim x As Double
        Dim y0, y1 As Double
        Dim m, b As Double

        y0 = v(0) * x0 ^ (3) + v(1) * x0 ^ (2) + v(2) * x0 + v(3)
        y1 = v(0) * x1 ^ (3) + v(1) * x1 ^ (2) + v(2) * x1 + v(3)

        m = (y1 - y0) / (x1 - x0)
        b = y0 - m * x0
        x = (0 - b) / m

        Return x

    End Function

    Public Function CubicSecant(x0 As Double, x1 As Double, tol As Double, maxIters As Integer, ByVal v() As Double) As Double


        Dim r, y As Double

        For i = 1 To maxIters
            r = Poly(x0, x1, v)
            y = v(0) * r ^ (3) + v(1) * r ^ (2) + v(2) * r + v(3)

            If Math.Abs(y) < tol Then
                Exit For
            Else
                x0 = x1
                x1 = r

            End If

        Next
        Return r
    End Function

End Module
